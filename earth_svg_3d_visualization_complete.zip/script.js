// === Scene setup ===
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.1,
  1000
);
camera.position.z = 10;

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.getElementById('container').appendChild(renderer.domElement);

// === Galaxy background ===
const starsGeometry = new THREE.BufferGeometry();
const starVertices = [];
for (let i = 0; i < 10000; i++) {
  starVertices.push(
    THREE.MathUtils.randFloatSpread(2000),
    THREE.MathUtils.randFloatSpread(2000),
    THREE.MathUtils.randFloatSpread(2000)
  );
}
starsGeometry.setAttribute('position', new THREE.Float32BufferAttribute(starVertices, 3));
const starMaterial = new THREE.PointsMaterial({ color: 0x8888ff });
const starField = new THREE.Points(starsGeometry, starMaterial);
scene.add(starField);

// === Earth with mipmapped texture ===
const textureLoader = new THREE.TextureLoader();
const earthTexture = textureLoader.load('assets/earthmap.jpg', (texture) => {
  texture.generateMipmaps = true;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.magFilter = THREE.LinearFilter;
});
const earthMaterial = new THREE.MeshPhongMaterial({ map: earthTexture, shininess: 10 });
const earthMesh = new THREE.Mesh(new THREE.SphereGeometry(4, 64, 64), earthMaterial);

// === Earth Group with axial tilt ===
const earthGroup = new THREE.Object3D();
earthGroup.rotation.z = THREE.MathUtils.degToRad(23.5);
earthGroup.add(earthMesh);
scene.add(earthGroup);

// === Atmosphere ===
const atmosphere = new THREE.Mesh(
  new THREE.SphereGeometry(4.075, 64, 64),
  new THREE.MeshPhongMaterial({
    color: 0x3399ff,
    transparent: true,
    opacity: 0.1,
    shininess: 50,
    side: THREE.DoubleSide
  })
);
earthGroup.add(atmosphere);

// === Lighting ===
const sunLight = new THREE.DirectionalLight(0xffffff, 1.5);
sunLight.position.set(5, 3, 5);
scene.add(sunLight);
scene.add(new THREE.AmbientLight(0x333333));

// === SVG continents ===
const loader = new THREE.SVGLoader();
loader.load('assets/world_map_real_professional.svg', (data) => {
  data.paths.forEach((path) => {
    const shapes = path.toShapes(true);
    shapes.forEach((shape) => {
      const geometry = new THREE.ShapeGeometry(shape);
      geometry.center();
      const material = new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide });
      const mesh = new THREE.Mesh(geometry, material);

      const pos = mesh.geometry.attributes.position;
      for (let i = 0; i < pos.count; i++) {
        const vertex = new THREE.Vector3().fromBufferAttribute(pos, i).normalize().multiplyScalar(3.01);
        pos.setXYZ(i, vertex.x, vertex.y, vertex.z);
      }

      earthGroup.add(mesh);
    });
  });
});

// === Satellites ===
const satellites = [];
const satelliteGeometry = new THREE.SphereGeometry(0.02, 8, 8);
const satelliteMaterial = new THREE.MeshBasicMaterial({ color: 0xffcc00 });
for (let i = 0; i < 5; i++) {
  const sat = new THREE.Mesh(satelliteGeometry, satelliteMaterial);
  scene.add(sat);
  satellites.push({ mesh: sat, speed: 0.005 + Math.random() * 0.01, angle: Math.random() * Math.PI * 2 });
}

// === Markers ===
const markersData = [{ lat: 0, lon: 0, name: "Center" }];
const markerGeometry = new THREE.SphereGeometry(0.03, 8, 8);
const markerMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 });
const markers = [];

markersData.forEach(data => {
  const phi = (90 - data.lat) * (Math.PI / 180);
  const theta = (data.lon + 180) * (Math.PI / 180);

  const marker = new THREE.Mesh(markerGeometry, markerMaterial);
  marker.position.set(
    Math.sin(phi) * Math.cos(theta),
    Math.cos(phi),
    Math.sin(phi) * Math.sin(theta)
  ).multiplyScalar(3.01);

  marker.userData = { name: data.name };
  earthGroup.add(marker);
  markers.push(marker);
});

// === Raycasting Click ===
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();
let enableEarthDrag = false;
let autoRotate = true;

renderer.domElement.addEventListener('click', (event) => {
  mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
  mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
  raycaster.setFromCamera(mouse, camera);

  const intersects = raycaster.intersectObjects([earthMesh]);

  if (intersects.length > 0) {
    // Clicked ON the Earth
    enableEarthDrag = true;
    autoRotate = false;
  } else {
    // Clicked OUTSIDE the Earth
    enableEarthDrag = false;
    autoRotate = true;
  }
});

// === Custom Earth Mouse Drag Rotation ===
let isDragging = false;
let previousMousePosition = { x: 0, y: 0 };

renderer.domElement.addEventListener('mousedown', () => {
  if (enableEarthDrag) isDragging = true;
});

renderer.domElement.addEventListener('mousemove', (event) => {
  if (isDragging) {
    const deltaMove = {
      x: event.clientX - previousMousePosition.x,
      y: event.clientY - previousMousePosition.y
    };

    const deltaQuat = new THREE.Quaternion()
      .setFromEuler(new THREE.Euler(
        THREE.MathUtils.degToRad(deltaMove.y * 0.1),
        THREE.MathUtils.degToRad(deltaMove.x * 0.1),
        0,
        'XYZ'
      ));

    earthGroup.quaternion.multiplyQuaternions(deltaQuat, earthGroup.quaternion);
  }

  previousMousePosition = {
    x: event.clientX,
    y: event.clientY
  };
});

renderer.domElement.addEventListener('mouseup', () => {
  isDragging = false;
});

renderer.domElement.addEventListener('mouseleave', () => {
  isDragging = false;
});

// === Zoom Scroll ===
renderer.domElement.addEventListener('wheel', (event) => {
  event.preventDefault();
  const delta = event.deltaY * 0.01;
  camera.position.z = THREE.MathUtils.clamp(camera.position.z + delta, 5, 50);
}, { passive: false });

// === Resize ===
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

// === Animate ===
function animate() {
  requestAnimationFrame(animate);

  if (autoRotate && !isDragging) {
    earthGroup.rotation.y += 0.001;
  }

  satellites.forEach(sat => {
    sat.angle += sat.speed;
    sat.mesh.position.set(
      Math.cos(sat.angle) * 4,
      Math.sin(sat.angle) * 4,
      Math.sin(sat.angle * 2) * 2
    );
  });

  starField.rotation.y += 0.00005;

  renderer.render(scene, camera);
}
animate();
